#include <stdlib.h>
#include <stdio.h>


int main(){
float M, A;
printf("Digite o valor do em acres:");
scanf("%f", &A);
M=A*4048.58;
printf("o Valor convertido para metros quadrados eh: %.2f", M);
system("pause");
return(0);


}
