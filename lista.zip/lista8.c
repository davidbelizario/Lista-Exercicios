#include <stdio.h>
#include <stdlib.h>

int main(){
int a;
scanf("%d", &a);
printf("O antecessor de %d eh %d e o sucessor eh %d\n", a, a-1, a+1);






system("pause");
return (0);
}
