#include <stdio.h>
#include <stdlib.h>
int main(){
float a;
float b;
float c;
printf("valor em real:");
scanf("%f", &a);
printf("cotacao do dolar:");
scanf("%f", &b);
c= a/b;
printf("o valor correspondente de reais em dolares eh: %f\n", c);








system("pause");
return (0);
}
