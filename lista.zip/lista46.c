#include <stdlib.h>
#include <stdio.h>


int main(){
float K, L;
printf("Digite o valor de massa em quilogramas:");
scanf("%f", &K);
L=K/0.45;
printf("o Valor convertido para libras eh: %.2f", L);
system("pause");
return(0);


}
