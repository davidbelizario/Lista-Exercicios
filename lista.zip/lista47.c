#include <stdlib.h>
#include <stdio.h>


int main(){
float K, L;
printf("Digite o valor de massa em libras:");
scanf("%f", &L);
K=L*0.45;
printf("o Valor convertido para quilogramas eh: %.2f", K);
system("pause");
return(0);


}
