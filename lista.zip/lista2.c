#include <stdio.h>
#include <stdlib.h>

int main(){
int a;
int b;
int c;
int d;
printf ("Digite 3 valores inteiros:");
scanf("%d", &a);
scanf("%d", &b);
scanf("%d", &c);
printf ("A soma dos 3 valores inteiros eh:");
d = (a+b+c);
printf("\n%d\n", d);

system("pause");
return (0);

}

