#include <stdio.h>
#include <stdlib.h>

int main(){
float a;
printf("Valor do lado do quadrado:");
scanf("%f", &a);
printf("A area do quadrado eh: %.2f\n", a*a);


system("pause");
return (0);
}
