#include <stdlib.h>
#include <stdio.h>


int main(){
float M, J;
printf("Digite o valor do comprimento em jardas:");
scanf("%f", &J);
M=J*0.91;
printf("o Valor convertido para metros eh: %.2f", M);
system("pause");
return(0);


}
