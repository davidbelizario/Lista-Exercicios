#include <stdio.h>
#include <stdlib.h>

int main(){
float a;
 scanf("%f", &a);
 printf ("o qudrado desse numero eh: %.2f", a*a);











system("pause");
return (0);
}
