#include <stdio.h>
#include <stdlib.h>
int main(){
float a;
float b;
printf("Digite o valor do produto:");
scanf("%f", &a);
b= (a* 0.88);
printf("o valor final com desconto eh %.2f", b);



system("pause");
return (0);
}
