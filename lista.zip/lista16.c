#include <stdio.h>
#include <stdlib.h>
int main(){
float a;
float b;
float c;
a= 780000*0.46;
b= 780000*0.32;
c= 780000*0.22;

printf("O primeiro ganhador recebera:%.f\n", a);
printf("O segundo ganhador recebera:%.f\n", b);
printf("O terceiro ganhador recebera:%.f\n", c);

system("pause");
return (0);
}
