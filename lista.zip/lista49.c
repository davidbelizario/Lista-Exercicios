#include <stdlib.h>
#include <stdio.h>


int main(){
float M, J;
printf("Digite o valor do comprimento em metros:");
scanf("%f", &M);
J=M/0.91;
printf("o Valor convertido para Jardas eh: %.2f", M);
system("pause");
return(0);


}
