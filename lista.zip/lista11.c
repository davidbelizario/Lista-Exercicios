#include <stdio.h>
#include <stdlib.h>
int main(){
float raio;
float area;


printf("O valor do raio:");
scanf ("%f", &raio);
area = (raio*raio) * 3.141592;
printf("o valor da area eh: %f\n", area);


system("pause");
return (0);


}

