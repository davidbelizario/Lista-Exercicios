#include <stdio.h>
#include <stdlib.h>

int main(){
int a=0;
float b=0;


scanf("%d", &a);
printf("o numero inteiro eh %d\n", a);
scanf("%f", &b);
printf("\n\no numero real eh %.2f", b);




system("pause");
return (0);

}
