#include <stdio.h>
#include <stdlib.h>

int main(){
float a;
float b;
scanf("%f", &a);
b = a/5;
printf("a quinta parte de %f eh: %f \n", a,b);











system("pause");
return (0);
}
