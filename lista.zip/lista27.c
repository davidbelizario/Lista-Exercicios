#include <stdio.h>
#include <stdlib.h>

int main(){
int idade;
int nascimento;
    printf("Digite a sua idade;");
    scanf("%d", &idade);
    nascimento=2020-idade;
    printf("o ano de nascimento eh:%d\n", nascimento);


    system("pause");
    return 0;

}
