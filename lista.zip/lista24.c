#include <stdio.h>
#include <stdlib.h>

int main(){
    int n1, n2, n3, n4;
    printf("Digite o numero: ");
    scanf("%1d%1d%1d%1d%*c", &n1, &n2, &n3, &n4);
    printf("%d\n %d\n %d\n %d\n", n1, n2, n3, n4);

    system("pause");
    return 0;

}
