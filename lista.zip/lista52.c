#include <stdlib.h>
#include <stdio.h>


int main(){
float M, H;
printf("Digite o valor do em metros qudrados:");
scanf("%f", &M);
H=M*0.0001;
printf("o Valor convertido para metros hectares eh: %.2f", H);
system("pause");
return(0);


}
